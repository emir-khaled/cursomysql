-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: restaurante
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `idlogin` int NOT NULL,
  `email` varchar(80) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `cliente_cliente_id` int NOT NULL,
  `cliente_domicilio_domicilio_id` int NOT NULL,
  PRIMARY KEY (`idlogin`,`cliente_cliente_id`,`cliente_domicilio_domicilio_id`),
  KEY `fk_login_cliente1_idx` (`cliente_cliente_id`,`cliente_domicilio_domicilio_id`),
  CONSTRAINT `fk_login_cliente1` FOREIGN KEY (`cliente_cliente_id`, `cliente_domicilio_domicilio_id`) REFERENCES `cliente` (`cliente_id`, `domicilio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'alonso@rodriguez.com','password',1,1),(2,'alex@perez.com','password',2,2),(3,'carlos@lopez.com','password',3,3),(4,'fer@martinez.com','password',4,4),(5,'luis@yanez.com','password',5,5),(6,'ana.gomez@example.com','password',6,6),(7,'juan.rodriguez@example.com','password',7,7),(8,'maria.gomez@example.com','password',8,8),(9,'juan.gomez@example.com','password',9,9),(10,'carlos.gomez@example.com','password',10,10),(11,'carlos.lopez@example.com','password',11,11),(12,'juan.rodriguez@example.com','password',12,12),(13,'carlos.perez@example.com','password',13,13),(14,'carlos.lopez@example.com','password',14,14),(15,'juan.perez@example.com','password',15,15),(16,'carlos.martinez@example.com','password',16,16),(17,'carlos.lopez@example.com','password',17,17),(18,'carlos.lopez@example.com','password',18,18),(19,'ana.lopez@example.com','password',19,19),(20,'ana.martinez@example.com','password',20,20),(21,'carlos.gomez@example.com','password',21,21),(22,'luis.martinez@example.com','password',22,22),(23,'juan.gomez@example.com','password',23,23),(24,'ana.lopez@example.com','password',24,24),(25,'luis.martinez@example.com','password',25,25),(26,'luis.rodriguez@example.com','password',26,26),(27,'ana.lopez@example.com','password',27,27),(28,'juan.rodriguez@example.com','password',28,28),(29,'luis.gomez@example.com','password',29,29),(30,'ana.lopez@example.com','password',30,30),(31,'carlos.lopez@example.com','password',31,31),(32,'ana.perez@example.com','password',32,32),(33,'maria.lopez@example.com','password',33,33),(34,'ana.martinez@example.com','password',34,34),(35,'carlos.martinez@example.com','password',35,35),(36,'maria.martinez@example.com','password',36,36),(37,'maria.rodriguez@example.com','password',37,37),(38,'carlos.perez@example.com','password',38,38),(39,'luis.lopez@example.com','password',39,39),(40,'luis.gomez@example.com','password',40,40),(41,'carlos.perez@example.com','password',41,41),(42,'carlosmartinez@example.com','password',42,42),(43,'anarodriguez@example.com','password',43,43),(44,'carlosmartinez@example.com','password',44,44),(45,'anarodriguez@example.com','password',45,45),(46,'juanprez@example.com','password',46,46),(47,'juanlopez@example.com','password',47,47),(48,'luisrodriguez@example.com','password',48,48),(49,'anagomez@example.com','password',49,49),(50,'anaperez@example.com','password',50,50),(52,'rafaellopez@example.com','password',52,52);
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-08 19:09:02
