-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: restaurante
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cuenta`
--

DROP TABLE IF EXISTS `cuenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cuenta` (
  `cuenta_id` int NOT NULL,
  `fecha` date NOT NULL,
  `cliente_cliente_id` int NOT NULL,
  `cliente_domicilio_domicilio_id` int NOT NULL,
  `estado_cuenta` enum('iniciada','procesando','entregada','cancelada') NOT NULL,
  `tipo_entrega` enum('domicilio','sucursal') NOT NULL,
  PRIMARY KEY (`cuenta_id`),
  KEY `fk_orden_cliente1_idx` (`cliente_cliente_id`,`cliente_domicilio_domicilio_id`),
  CONSTRAINT `fk_orden_cliente1` FOREIGN KEY (`cliente_cliente_id`, `cliente_domicilio_domicilio_id`) REFERENCES `cliente` (`cliente_id`, `domicilio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuenta`
--

LOCK TABLES `cuenta` WRITE;
/*!40000 ALTER TABLE `cuenta` DISABLE KEYS */;
INSERT INTO `cuenta` VALUES (1,'2023-11-01',1,1,'entregada','domicilio'),(2,'2023-10-01',2,2,'entregada','sucursal'),(3,'2023-10-01',3,3,'entregada','domicilio'),(4,'2023-10-02',4,4,'entregada','sucursal'),(5,'2023-10-02',5,5,'entregada','domicilio'),(6,'2023-10-02',6,6,'entregada','sucursal'),(7,'2023-10-03',7,7,'entregada','domicilio'),(8,'2023-10-03',8,8,'cancelada','sucursal'),(9,'2023-10-03',9,9,'entregada','sucursal'),(10,'2023-10-03',10,10,'entregada','domicilio'),(11,'2023-10-04',11,11,'entregada','sucursal'),(12,'2023-10-04',12,12,'entregada','sucursal'),(13,'2023-10-04',13,13,'entregada','sucursal'),(14,'2023-10-05',14,14,'entregada','sucursal'),(15,'2023-10-05',15,15,'entregada','domicilio'),(16,'2023-10-05',16,16,'cancelada','domicilio'),(17,'2023-10-06',17,17,'entregada','sucursal'),(18,'2023-10-06',18,18,'cancelada','sucursal'),(19,'2023-10-06',19,19,'iniciada','domicilio'),(20,'2023-10-07',20,20,'iniciada','domicilio'),(21,'2023-10-07',21,21,'entregada','sucursal'),(22,'2023-10-07',22,22,'entregada','sucursal'),(23,'2023-10-08',23,23,'entregada','domicilio'),(24,'2023-10-08',24,24,'cancelada','sucursal'),(25,'2023-10-08',25,25,'entregada','domicilio'),(26,'2023-10-09',26,26,'iniciada','sucursal'),(27,'2023-10-09',27,27,'entregada','domicilio'),(28,'2023-10-10',28,28,'entregada','domicilio'),(29,'2023-10-10',29,29,'entregada','sucursal'),(30,'2023-10-11',30,30,'entregada','sucursal'),(31,'2023-10-11',31,31,'procesando','domicilio'),(32,'2023-10-12',32,32,'entregada','sucursal'),(33,'2023-10-12',33,33,'cancelada','domicilio'),(34,'2023-10-13',34,34,'entregada','sucursal'),(35,'2023-10-14',35,35,'cancelada','sucursal'),(36,'2023-10-15',36,36,'iniciada','domicilio'),(37,'2023-10-15',37,37,'iniciada','sucursal'),(38,'2023-10-15',38,38,'procesando','domicilio'),(39,'2023-10-16',39,39,'entregada','sucursal'),(40,'2023-10-16',40,40,'entregada','sucursal'),(41,'2023-10-17',41,41,'cancelada','domicilio'),(42,'2023-10-17',42,42,'procesando','sucursal'),(43,'2023-10-17',43,43,'iniciada','domicilio'),(44,'2023-10-18',44,44,'procesando','sucursal'),(45,'2023-10-18',45,45,'procesando','sucursal'),(46,'2023-10-19',46,46,'procesando','domicilio'),(47,'2023-10-19',47,47,'procesando','sucursal'),(48,'2023-10-20',48,48,'entregada','domicilio'),(49,'2023-10-20',49,49,'cancelada','sucursal'),(50,'2023-10-21',50,50,'entregada','sucursal'),(51,'2023-10-21',1,1,'cancelada','domicilio'),(52,'2023-10-21',2,2,'iniciada','sucursal'),(53,'2023-10-22',3,3,'iniciada','domicilio'),(54,'2023-10-23',4,4,'procesando','sucursal'),(55,'2023-10-23',5,5,'entregada','sucursal'),(56,'2023-10-24',6,6,'entregada','domicilio'),(57,'2023-10-24',7,7,'cancelada','sucursal'),(58,'2023-10-24',8,8,'procesando','domicilio'),(59,'2023-10-24',9,9,'iniciada','sucursal'),(60,'2023-10-25',10,10,'procesando','sucursal'),(61,'2023-10-25',11,11,'procesando','domicilio'),(62,'2023-10-25',12,12,'procesando','sucursal'),(63,'2023-10-26',13,13,'procesando','domicilio'),(64,'2023-10-26',14,14,'entregada','sucursal'),(65,'2023-10-26',15,15,'cancelada','sucursal'),(66,'2023-10-27',16,16,'entregada','domicilio'),(67,'2023-10-27',17,17,'cancelada','sucursal'),(68,'2023-10-28',18,18,'iniciada','domicilio'),(69,'2023-10-28',19,19,'iniciada','sucursal'),(70,'2023-10-28',20,20,'procesando','sucursal'),(71,'2023-10-29',21,21,'entregada','domicilio'),(72,'2023-10-29',22,22,'entregada','sucursal'),(73,'2023-10-29',23,23,'cancelada','domicilio'),(74,'2023-10-30',24,24,'procesando','sucursal'),(75,'2023-10-30',25,25,'iniciada','sucursal'),(76,'2023-10-31',26,26,'procesando','domicilio'),(77,'2023-10-31',27,27,'procesando','sucursal'),(78,'2023-10-31',28,28,'procesando','domicilio'),(79,'2023-10-31',29,29,'entregada','domicilio'),(80,'2023-11-01',2,2,'entregada','sucursal'),(81,'2023-11-02',4,4,'entregada','sucursal'),(82,'2023-11-02',5,5,'entregada','domicilio'),(83,'2023-11-08',52,52,'iniciada','domicilio'),(84,'2023-11-08',52,52,'cancelada','domicilio');
/*!40000 ALTER TABLE `cuenta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-08 19:09:02
