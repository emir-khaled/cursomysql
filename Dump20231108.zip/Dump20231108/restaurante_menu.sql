-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: restaurante
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `idmenu` int NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `precio` float NOT NULL,
  `tipo` enum('bebida','acompanamiento','entrada','postre','alimento') DEFAULT NULL,
  PRIMARY KEY (`idmenu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'Filete de solomillo',285.5,'alimento'),(2,'Costilla de res a la parrilla',245.75,'alimento'),(3,'Chuletas de cordero en salsa de menta',134.9,'alimento'),(4,'Asado de cerdo con hierbas',145.5,'alimento'),(5,'T-bone a la brasa',345.8,'alimento'),(6,'Estofado de carne con verduras',189,'alimento'),(7,'Hamburguesa gourmet',125.5,'alimento'),(8,'Chuletas de cerdo glaseadas',182.8,'alimento'),(9,'Ribeye al punto',389,'alimento'),(10,'Kebabs de ternera',210,'alimento'),(11,'Carne de cerdo a la barbacoa',189,'alimento'),(12,'Tacos de carne de res asada',35.8,'alimento'),(13,'Picanha brasileña',200,'alimento'),(14,'Filete de atún sellado',187,'alimento'),(15,'Brochetas de pollo y ternera',245,'alimento'),(16,'Carne desmenuzada estilo BBQ',189.54,'alimento'),(17,'Fajitas de ternera con pimientos',145.87,'alimento'),(18,'Cordero asado con romero',210,'alimento'),(19,'Solomillo Wellington',185,'alimento'),(20,'Pollo al limón con hierbas',150,'alimento'),(21,'Pato a la naranja glaseado',320,'alimento'),(22,'Chicharrón de Rib Eye',200,'entrada'),(23,'Palomitas de Coliflor',150,'entrada'),(24,'Queso Fundido',139,'entrada'),(25,'Guacamole',137.5,'entrada'),(26,'Vino tinto',192.5,'bebida'),(27,'Vino blanco seco',140.5,'bebida'),(28,'Cerveza artesanal',94.75,'bebida'),(29,'Margarita de fresa',182.9,'bebida'),(30,'Mojito refrescante',113.25,'bebida'),(31,'Piña colada tropical',120.25,'bebida'),(32,'Sangría española',163.4,'bebida'),(33,'Moscow Mule',154.1,'bebida'),(34,'Agua de coco natural',55.45,'bebida'),(35,'Limonada casera',71.5,'bebida'),(36,'Té helado de durazno',54.1,'bebida'),(37,'Whisky escocés',150.56,'bebida'),(38,'Martini seco',187.54,'bebida'),(39,'Sidra espumosa',156.48,'bebida'),(40,'Café espresso',45.78,'bebida'),(41,'Agua con gas',65.1,'bebida'),(42,'Refresco de cola',45.63,'bebida'),(43,'Jugo de naranja recién exprimido',70.43,'bebida'),(44,'Té de hierbabuena',40,'bebida'),(45,'Mocktail de sandía y menta',80.45,'bebida'),(46,'Tiramisú italiano',125,'postre'),(47,'Pastel de chocolate triple',82.43,'postre'),(48,'Crème brûlée con frutos rojos',110.61,'postre'),(49,'Helado de vainilla con caramelo',83.12,'postre'),(50,'Tarta de manzana casera',54.86,'postre'),(51,'Mousse de mango',71.89,'postre'),(52,'Cheesecake de fresa',98.45,'postre'),(53,'Profiteroles rellenos de crema',123.59,'postre'),(54,'Brownie de nueces con helado',92.63,'postre'),(55,'Flan de caramelo',76.15,'postre'),(56,'Soufflé de chocolate caliente',91,'postre'),(57,'Crepes con Nutella y plátano',45.12,'postre'),(58,'Pastel de zanahoria con crema de queso',120.14,'postre'),(59,'Panna cotta con coulis de frambuesa',124,'postre'),(60,'Frutas frescas con salsa de chocolate',45,'postre'),(61,'Tarta de limón y merengue',95,'postre'),(62,'Sorbete de frambuesa',87.95,'postre'),(63,'Galletas recién horneadas',35.78,'postre'),(64,'Mousse de maracuyá',98.45,'postre'),(65,'Copa de frutas con yogurt',85.47,'postre');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-08 19:09:02
