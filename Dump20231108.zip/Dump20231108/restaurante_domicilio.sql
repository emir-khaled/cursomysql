-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: restaurante
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `domicilio`
--

DROP TABLE IF EXISTS `domicilio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `domicilio` (
  `domicilio_id` int DEFAULT NULL,
  `calle` text,
  `colonia` text,
  `numero` int DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domicilio`
--

LOCK TABLES `domicilio` WRITE;
/*!40000 ALTER TABLE `domicilio` DISABLE KEYS */;
INSERT INTO `domicilio` VALUES (1,' Calle Principal',' Zapopan',123,'913736977'),(2,' Avenida Secundaria',' Tlaquepaque',456,'939858742'),(3,' Carretera Principal',' Tonala',789,'960672378'),(4,' Plaza del Pueblo',' El Colli',101,'950683677'),(5,' Camino de la Playa',' Miravalle',202,'938541649'),(6,' Paseo del Parque',' Chapalita',303,'946109396'),(7,' CallejÃ³n Escondido',' Providencia',404,'932787249'),(8,' Avenida Central',' La Estancia',505,'907429436'),(9,' Calle de la EstaciÃ³n',' Americana',606,'926201254'),(10,' Avenida de la MontaÃ±a',' Vallarta Poniente',707,'948811435'),(11,' Paseo del RÃ­o',' Lomas del Valle',808,'975316461'),(12,' CallejÃ³n sin Salida',' LadrÃ³n de Guevara',909,'963505805'),(13,' Calle de la Iglesia',' Jardines del Sol',111,'964110436'),(14,' Avenida del Lago',' Arcos Vallarta',222,'966508988'),(15,' Carretera de MontaÃ±a',' Santa Tere',333,'937401866'),(16,' Plaza del Mercado',' Jardines de la Patria',444,'930861954'),(17,' Camino del Bosque',' Ciudad del Sol',555,'988243920'),(18,' Avenida del Centro',' Ladron de Guevara',666,'937137846'),(19,' Paseo del Mar',' La Calma',777,'901650115'),(20,' Calle de la Ciudad',' Lomas de Guevara',888,'932305715'),(21,' Avenida del Parque',' Guadalupe Inn',999,'981611492'),(22,' Calle de la Escuela',' Arboledas',121,'901013175'),(23,' Avenida de la Playa',' Chapultepec',232,'977675050'),(24,' Carretera de la MontaÃ±a',' Del Fresno',343,'995402316'),(25,' Plaza del Ayuntamiento',' Jardines Universidad',454,'902764746'),(26,' Camino del RÃ­o',' San AgustÃ­n',565,'957491311'),(27,' Paseo del Bosque',' Toluquilla',676,'912270308'),(28,' Calle de la EstaciÃ³n',' Zapopan Centro',787,'997137605'),(29,' Avenida de la MontaÃ±a',' Las Fuentes',898,'914284275'),(30,' CallejÃ³n del Parque',' Los Almendros',909,'989757432'),(31,' Calle del Comercio',' Tlajomulco de ZÃºÃ±iga',131,'914593986'),(32,' Avenida del Centro',' Jardines de la Cruz',242,'946524007'),(33,' Carretera de la Playa',' Los Laureles',353,'951014977'),(34,' Plaza del Parque',' Colinas de San Javier',464,'923117935'),(35,' Camino del Lago',' Vallarta Universidad',575,'964853288'),(36,' Paseo de la MontaÃ±a',' Lomas Altas',686,'998095261'),(37,' Calle del JardÃ­n',' El Manantial',797,'978728875'),(38,' Avenida de la Plaza',' Independencia',808,'926790862'),(39,' Calle de la Fuente',' Arboledas Vallarta',919,'951298057'),(40,' Calle del Bosque',' San Rafael',141,'985011636'),(41,' Avenida de la MontaÃ±a',' La Loma',252,'939464584'),(42,' Carretera de la Ciudad',' Colonia Jalisco',363,'905876603'),(43,' Plaza del Mercado',' La Perla',474,'989879212'),(44,' Camino de la Iglesia',' Los Pinos',585,'954446282'),(45,' Paseo de la Playa',' Analco',696,'902442797'),(46,' Calle del Pueblo',' Santa Isabel',707,'928564300'),(47,' Avenida del Comercio',' Ciudad Bugambilias',818,'968889146'),(48,' CallejÃ³n de la Ciudad',' Rinconada del Bosque',929,'948042785'),(49,' Calle del Ayuntamiento',' Paseos del Sol',151,'904845747'),(50,' Avenida del RÃ­o',' Santa MarÃ­a del Oro',262,'948515793'),(52,'Uranio','Quimica',100,'355236978');
/*!40000 ALTER TABLE `domicilio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-08 19:09:01
