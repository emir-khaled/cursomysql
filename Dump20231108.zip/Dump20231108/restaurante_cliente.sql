-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: restaurante
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `nombre` varchar(35) NOT NULL,
  `apellidos` varchar(45) NOT NULL,
  `cliente_id` int NOT NULL,
  `domicilio_id` int NOT NULL,
  `datos_fiscales_id` int NOT NULL,
  PRIMARY KEY (`cliente_id`,`domicilio_id`),
  KEY `fk_cliente_domicilio1_idx` (`domicilio_id`),
  KEY `fk_cliente_datos_fiscales1_idx` (`datos_fiscales_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES ('Ana',' Rodriguez',45,45,45),('Carlos',' Martinez',44,44,44),('Ana',' Rodriguez',43,43,43),('Carlos',' Martinez',42,42,42),('Carlos',' Lopez',41,41,41),('Luis',' Lopez',40,40,40),('Luis',' Gomez',39,39,39),('Carlos',' Perez',38,38,38),('Maria',' Gomez',37,37,37),('Maria',' Gomez',36,36,36),('Carlos',' Rodriguez',35,35,35),('Ana',' Lopez',34,34,34),('Maria',' Rodriguez',33,33,33),('Ana',' Martinez',32,32,32),('Carlos',' Gomez',31,31,31),('Ana',' Martinez',30,30,30),('Luis',' Perez',29,29,29),('Juan',' Lopez',28,28,28),('Ana',' Lopez',27,27,27),('Luis',' Gomez',26,26,26),('Luis',' Rodriguez',25,25,25),('Ana',' Lopez',24,24,24),('Juan',' Rodriguez',23,23,23),('Luis',' Lopez',22,22,22),('Carlos',' Martinez',21,21,21),('Ana',' Gomez',20,20,20),('Ana',' Martinez',19,19,19),('Carlos',' Lopez',18,18,18),('Carlos',' Lopez',17,17,17),('Carlos',' Martinez',16,16,16),('Juan',' Perez',15,15,15),('Carlos',' Lopez',14,14,14),('Carlos',' Perez',13,13,13),('Juan',' Rodriguez',12,12,12),('Carlos',' Lopez',11,11,11),('Carlos',' Gomez',10,10,10),('Juan',' Gomez',9,9,9),('Maria',' Gomez',8,8,8),('Juan',' Rodriguez',7,7,7),('Ana',' Gomez',6,6,6),('Luis',' Yanez',5,5,5),('Fernando',' Martinez',4,4,4),('Carlos',' Lopez',3,3,3),('Alexander',' Perez',2,2,2),('Alonso',' Rodriguez',1,1,1),('Ana',' Perez',50,50,50),('Ana',' Gomez',49,49,49),('Luis',' Rodriguez',48,48,48),('Juan',' Lopez',47,47,47),('Juan',' Perez',46,46,46),('Rafael','Lopez',52,52,52);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-08 19:09:02
