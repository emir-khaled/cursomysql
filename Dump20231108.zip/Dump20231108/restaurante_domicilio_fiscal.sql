-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: restaurante
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `domicilio_fiscal`
--

DROP TABLE IF EXISTS `domicilio_fiscal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `domicilio_fiscal` (
  `idFiscalDomicilio` int NOT NULL,
  `calle` varchar(45) NOT NULL,
  `colonia` varchar(45) NOT NULL,
  `cp` varchar(45) NOT NULL,
  `estado` varchar(45) NOT NULL,
  `numero` int NOT NULL,
  `ciudad` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idFiscalDomicilio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domicilio_fiscal`
--

LOCK TABLES `domicilio_fiscal` WRITE;
/*!40000 ALTER TABLE `domicilio_fiscal` DISABLE KEYS */;
INSERT INTO `domicilio_fiscal` VALUES (1,' Calle Principal',' Zapopan','45123','Jalisco',123,'Zapopan'),(2,' Avenida Secundaria',' Tlaquepaque','45124','Jalisco',456,'Zapopan'),(3,' Carretera Principal',' Tonala','45125','Jalisco',789,'Zapopan'),(4,' Plaza del Pueblo',' El Colli','45126','Jalisco',101,'Zapopan'),(5,' Camino de la Playa',' Miravalle','45127','Jalisco',202,'Zapopan'),(6,' Paseo del Parque',' Chapalita','45128','Jalisco',303,'Zapopan'),(7,' Callejón Escondido',' Providencia','45129','Jalisco',404,'Zapopan'),(8,' Avenida Central',' La Estancia','45130','Jalisco',505,'Zapopan'),(9,' Calle de la Estación',' Americana','45131','Jalisco',606,'Zapopan'),(10,' Avenida de la Montaña',' Vallarta Poniente','45132','Jalisco',707,'Zapopan'),(11,' Paseo del Río',' Lomas del Valle','45133','Jalisco',808,'Zapopan'),(12,' Callejón sin Salida',' Ladrón de Guevara','45134','Jalisco',909,'Zapopan'),(13,' Calle de la Iglesia',' Jardines del Sol','45135','Jalisco',111,'Zapopan'),(14,' Avenida del Lago',' Arcos Vallarta','45136','Jalisco',222,'Zapopan'),(15,' Carretera de Montaña',' Santa Tere','45137','Jalisco',333,'Zapopan'),(16,' Plaza del Mercado',' Jardines de la Patria','45138','Jalisco',444,'Zapopan'),(17,' Camino del Bosque',' Ciudad del Sol','45139','Jalisco',555,'Zapopan'),(18,' Avenida del Centro',' Ladron de Guevara','45140','Jalisco',666,'Zapopan'),(19,' Paseo del Mar',' La Calma','45141','Jalisco',777,'Zapopan'),(20,' Calle de la Ciudad',' Lomas de Guevara','45142','Jalisco',888,'Zapopan'),(21,' Avenida del Parque',' Guadalupe Inn','45143','Jalisco',999,'Zapopan'),(22,' Calle de la Escuela',' Arboledas','45144','Jalisco',121,'Zapopan'),(23,' Avenida de la Playa',' Chapultepec','45145','Jalisco',232,'Zapopan'),(24,' Carretera de la Montaña',' Del Fresno','45146','Jalisco',343,'Zapopan'),(25,' Plaza del Ayuntamiento',' Jardines Universidad','45147','Jalisco',454,'Guadalajara'),(26,' Camino del Río',' San Agustín','45148','Jalisco',565,'Guadalajara'),(27,' Paseo del Bosque',' Toluquilla','45149','Jalisco',676,'Guadalajara'),(28,' Calle de la Estación',' Zapopan Centro','45150','Jalisco',787,'Guadalajara'),(29,' Avenida de la Montaña',' Las Fuentes','45151','Jalisco',898,'Guadalajara'),(30,' Callejón del Parque',' Los Almendros','45152','Jalisco',909,'Guadalajara'),(31,' Calle del Comercio',' Tlajomulco de Zúñiga','45153','Jalisco',131,'Guadalajara'),(32,' Avenida del Centro',' Jardines de la Cruz','45154','Jalisco',242,'Guadalajara'),(33,' Carretera de la Playa',' Los Laureles','45135','Jalisco',353,'Guadalajara'),(34,' Plaza del Parque',' Colinas de San Javier','45136','Jalisco',464,'Guadalajara'),(35,' Camino del Lago',' Vallarta Universidad','45137','Jalisco',575,'Guadalajara'),(36,' Paseo de la Montaña',' Lomas Altas','45138','Jalisco',686,'Guadalajara'),(37,' Calle del Jardín',' El Manantial','45139','Jalisco',797,'Guadalajara'),(38,' Avenida de la Plaza',' Independencia','45140','Jalisco',808,'Guadalajara'),(39,' Calle de la Fuente',' Arboledas Vallarta','45141','Jalisco',919,'Guadalajara'),(40,' Calle del Bosque',' San Rafael','45142','Jalisco',141,'Guadalajara'),(41,' Avenida de la Montaña',' La Loma','45143','Jalisco',252,'Guadalajara'),(42,' Carretera de la Ciudad',' Colonia Jalisco','45144','Jalisco',363,'Guadalajara'),(43,' Plaza del Mercado',' La Perla','45145','Jalisco',474,'Guadalajara'),(44,' Camino de la Iglesia',' Los Pinos','45146','Jalisco',585,'Guadalajara'),(45,' Paseo de la Playa',' Analco','45147','Jalisco',696,'Guadalajara'),(46,' Calle del Pueblo',' Santa Isabel','45148','Jalisco',707,'Guadalajara'),(47,' Avenida del Comercio',' Ciudad Bugambilias','45149','Jalisco',818,'Guadalajara'),(48,' Callejón de la Ciudad',' Rinconada del Bosque','45150','Jalisco',929,'Guadalajara'),(49,' Calle del Ayuntamiento',' Paseos del Sol','45151','Jalisco',151,'Guadalajara'),(50,' Avenida del Río',' Santa María del Oro','45152','Jalisco',262,'Tonala'),(52,'Calle 1','Numeros','45153','Jalisco',263,'Guadalajara');
/*!40000 ALTER TABLE `domicilio_fiscal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-08 19:09:02
