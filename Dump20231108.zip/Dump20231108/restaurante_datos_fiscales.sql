-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: restaurante
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `datos_fiscales`
--

DROP TABLE IF EXISTS `datos_fiscales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datos_fiscales` (
  `datos_fiscales_id` int NOT NULL,
  `RFC` varchar(15) NOT NULL,
  `situacion fiscal` varchar(45) NOT NULL,
  `domicilio_fiscal_idFiscalDomicilio` int NOT NULL,
  PRIMARY KEY (`datos_fiscales_id`,`domicilio_fiscal_idFiscalDomicilio`),
  KEY `fk_datos_fiscales_domicilio_fiscal1_idx` (`domicilio_fiscal_idFiscalDomicilio`),
  CONSTRAINT `fk_datos_fiscales_domicilio_fiscal1` FOREIGN KEY (`domicilio_fiscal_idFiscalDomicilio`) REFERENCES `domicilio_fiscal` (`idFiscalDomicilio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datos_fiscales`
--

LOCK TABLES `datos_fiscales` WRITE;
/*!40000 ALTER TABLE `datos_fiscales` DISABLE KEYS */;
INSERT INTO `datos_fiscales` VALUES (1,'RodAlons123A4','Persona Física',1),(2,'PerAlexa114P5','Persona Moral',2),(3,'LopCarlo345L6','Persona Física',3),(4,'MarFerna456M7','Persona Moral',4),(5,'YankLuis567Y8','Persona Física',5),(6,'GomAna678G9P1','persona Moral',6),(7,'RodJuan789R06','Persona Física',7),(8,'GomMaría890G1','Persona Moral',8),(9,'GomJuan901G27','Persona Física',9),(10,'GomCarlo012G3','Persona Moral',10),(11,'LopCalos123L4','Persona Física',11),(12,'LopCaros456L7','Persona Moral',12),(13,'PerJuan567P81','Persona Física',13),(14,'MarCalos678M9','Persona Moral',14),(15,'PerJuan567P82','Persona Física',15),(16,'MarCarlo678M9','Persona Moral',16),(17,'LopCaros789L0','Persona Física',17),(18,'LoCarlos890L1','Persona Moral',18),(19,'MarAna901M223','Persona Física',19),(20,'GomAna012G331','Persona Moral',20),(21,'MarCarlos1232','Persona Física',21),(22,'LopLuis234L54','Persona Moral',22),(23,'RodJuan345R62','Persona Física',23),(24,'LopAna456L713','Persona Moral',24),(25,'RodLuis567R85','Persona Física',25),(26,'GomLuis678G96','Persona Moral',26),(27,'LopAna789L014','Persona Física',27),(28,'LopJuan890L18','Persona Moral',28),(29,'PerLuis901P23','Persona Física',29),(30,'MarAna012M315','Persona Moral',30),(31,'GomCarlos123G','Persona Física',31),(32,'MarAna234M512','Persona Moral',32),(33,'RodMaría345R6','Persona Física',33),(34,'LopAna456L718','Persona Moral',34),(35,'RodCarlos567R','Persona Física',35),(36,'GomMaría678G9','Persona Física',36),(37,'GomMaría789G0','Persona Moral',37),(38,'PerCarlos890P','Persona Física',38),(39,'GomLuis901G20','Persona Fisica',39),(40,'LopLuis012L38','Persona Moral',40),(41,'LopCarlos123L','persona Física',41),(42,'MarCarlos234M','Persona Moral',42),(43,'RodAna345R612','Persona Física',43),(44,'MarCarlos456M','Persona Moral',44),(45,'RodAna567R812','Persona Física',45),(46,'PerJuan678P98','Persona Moral',46),(47,'LopJuan789L01','Persona Física',47),(48,'RodLuis890R18','Persona Moral',48),(49,'GomAna901G234','Persona Física',49),(50,'PerAna012P389','Persona Moral',50),(52,'LOGRaf12Q568','Persona Moral',52);
/*!40000 ALTER TABLE `datos_fiscales` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-08 19:09:01
